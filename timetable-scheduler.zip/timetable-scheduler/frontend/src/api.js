const json = (body) => ({ headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
const wrap = (r) => r.json().then((data) => ({ ok: r.ok, data }));

export const api = {
  list: (name) => fetch(`/api/${name}`).then((r) => r.json()),
  add: (name, body) => fetch(`/api/${name}`, { method: "POST", ...json(body) }).then(wrap),
  remove: (name, id) => fetch(`/api/${name}/${id}`, { method: "DELETE" }),
  seed: () => fetch("/api/seed", { method: "POST" }).then(wrap),
  generate: () => fetch("/api/generate", { method: "POST" }).then(wrap),
  timetable: () => fetch("/api/timetable").then((r) => r.json()),
  move: (id, body) => fetch(`/api/timetable/${id}`, { method: "PUT", ...json(body) }).then(wrap),
};
