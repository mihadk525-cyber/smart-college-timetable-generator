import { useEffect, useState } from "react";
import { api } from "./api";

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri"];
const TIMES = ["09:00", "10:00", "11:00", "12:00", "14:00", "15:00"];

const RESOURCES = {
  faculty: { label: "Faculty", fields: [["name", "text"]] },
  batches: { label: "Student batches", fields: [["name", "text"], ["size", "number"]] },
  rooms: { label: "Classrooms and labs", fields: [["name", "text"], ["capacity", "number"], ["is_lab", "checkbox"]] },
  slots: { label: "Time slots (day 0 = Mon, period 0 = first)", fields: [["day", "number"], ["period", "number"]] },
  subjects: {
    label: "Subjects",
    fields: [["code", "text"], ["name", "text"], ["faculty_id", "number"], ["batch_id", "number"],
             ["lectures_per_week", "number"], ["is_lab", "checkbox"]],
  },
  unavailability: { label: "Faculty unavailable (faculty id, slot id)", fields: [["faculty_id", "number"], ["slot_id", "number"]] },
};

function ResourcePanel({ name, cfg }) {
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState({});
  const load = () => api.list(name).then(setRows);
  useEffect(() => { load(); }, [name]);

  const add = async (e) => {
    e.preventDefault();
    const body = {};
    for (const [f, type] of cfg.fields) {
      body[f] = type === "number" ? Number(form[f]) : type === "checkbox" ? !!form[f] : form[f];
    }
    await api.add(name, body);
    setForm({});
    load();
  };

  return (
    <section className="panel">
      <h3>{cfg.label}</h3>
      <form onSubmit={add} className="inline-form">
        {cfg.fields.map(([f, type]) =>
          type === "checkbox" ? (
            <label key={f}><input type="checkbox" checked={!!form[f]} onChange={(e) => setForm({ ...form, [f]: e.target.checked })} /> {f}</label>
          ) : (
            <input key={f} type={type} placeholder={f} required value={form[f] ?? ""}
                   onChange={(e) => setForm({ ...form, [f]: e.target.value })} />
          )
        )}
        <button>Add</button>
      </form>
      <ul className="rows">
        {rows.map((r) => (
          <li key={r.id}>
            <span>{Object.entries(r).map(([k, v]) => `${k}: ${v}`).join(", ")}</span>
            <button className="quiet" onClick={async () => { await api.remove(name, r.id); load(); }}>Delete</button>
          </li>
        ))}
      </ul>
    </section>
  );
}

function Timetable() {
  const [entries, setEntries] = useState([]);
  const [slots, setSlots] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [batches, setBatches] = useState([]);
  const [batchId, setBatchId] = useState(null);
  const [msg, setMsg] = useState("");
  const [edit, setEdit] = useState(null);

  const load = async () => {
    const [t, s, r, b] = await Promise.all([api.timetable(), api.list("slots"), api.list("rooms"), api.list("batches")]);
    setEntries(t); setSlots(s); setRooms(r); setBatches(b);
    setBatchId((cur) => cur ?? b[0]?.id ?? null);
  };
  useEffect(() => { load(); }, []);

  const generate = async () => {
    setMsg("Generating timetable...");
    const { ok, data } = await api.generate();
    setMsg(ok ? `Timetable generated: ${data.nodes} search steps in ${data.elapsed_ms.toFixed(1)} ms.` : data.message);
    load();
  };
  const loadSample = async () => { await api.seed(); setMsg("Sample data loaded. Generate a timetable next."); load(); };

  const save = async () => {
    const slot = slots.find((s) => s.day === edit.day && s.period === edit.period);
    if (!slot) return setMsg("That day and period has no time slot. Add one in Setup first.");
    const { ok, data } = await api.move(edit.id, { slot_id: slot.id, room_id: edit.room_id });
    setMsg(ok ? "Lecture moved." : `Can't move: ${data.conflicts.join("; ")}`);
    if (ok) setEdit(null);
    load();
  };

  const periods = [...new Set(slots.map((s) => s.period))].sort((a, b) => a - b);
  const cell = (d, p) => entries.find((e) => e.batch_id === batchId && e.day === d && e.period === p);
  const labRooms = new Set(rooms.filter((r) => r.is_lab).map((r) => r.id));

  return (
    <>
      <div className="toolbar">
        <button onClick={generate}>Generate timetable</button>
        <button className="secondary" onClick={loadSample}>Load sample data</button>
        <a className="button secondary" href="/api/timetable/export">Export CSV</a>
        <select value={batchId ?? ""} onChange={(e) => setBatchId(Number(e.target.value))}>
          {batches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
      </div>
      {msg && <p className="status" role="status">{msg}</p>}

      <div className="grid-wrap">
        <table className="grid">
          <thead>
            <tr><th></th>{DAYS.map((d) => <th key={d}>{d}</th>)}</tr>
          </thead>
          <tbody>
            {periods.map((p) => (
              <tr key={p}>
                <th>{TIMES[p] ?? `P${p + 1}`}</th>
                {DAYS.map((_, d) => {
                  const e = cell(d, p);
                  return (
                    <td key={d}>
                      {e && (
                        <button className={`lecture ${labRooms.has(e.room_id) ? "lab" : ""}`}
                                onClick={() => setEdit({ id: e.id, day: e.day, period: e.period, room_id: e.room_id, label: e.code })}>
                          <strong>{e.code}</strong>
                          <span>{e.room}</span>
                          <span>{e.faculty}</span>
                        </button>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {edit && (
        <section className="panel">
          <h3>Move {edit.label}</h3>
          <div className="inline-form">
            <select value={edit.day} onChange={(e) => setEdit({ ...edit, day: Number(e.target.value) })}>
              {DAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}
            </select>
            <select value={edit.period} onChange={(e) => setEdit({ ...edit, period: Number(e.target.value) })}>
              {periods.map((p) => <option key={p} value={p}>{TIMES[p] ?? `P${p + 1}`}</option>)}
            </select>
            <select value={edit.room_id} onChange={(e) => setEdit({ ...edit, room_id: Number(e.target.value) })}>
              {rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
            </select>
            <button onClick={save}>Save move</button>
            <button className="secondary" onClick={() => setEdit(null)}>Cancel</button>
          </div>
        </section>
      )}
    </>
  );
}

export default function App() {
  const [tab, setTab] = useState("timetable");
  return (
    <main>
      <header>
        <h1>College Timetable Scheduler</h1>
        <nav>
          <button className={tab === "timetable" ? "active" : "quiet"} onClick={() => setTab("timetable")}>Timetable</button>
          <button className={tab === "setup" ? "active" : "quiet"} onClick={() => setTab("setup")}>Setup</button>
        </nav>
      </header>
      {tab === "timetable" ? <Timetable /> : Object.entries(RESOURCES).map(([n, cfg]) => <ResourcePanel key={n} name={n} cfg={cfg} />)}
    </main>
  );
}
