from app import create_app


def make_client():
    client = create_app("sqlite:///:memory:").test_client()
    assert client.post("/api/seed").status_code == 200
    assert client.post("/api/generate").status_code == 200
    return client


def test_generate_then_no_conflicts():
    client = make_client()
    assert len(client.get("/api/timetable").get_json()) == 44
    assert client.get("/api/conflicts").get_json()["conflicts"] == []


def test_manual_move_into_clash_is_rejected():
    client = make_client()
    rows = client.get("/api/timetable").get_json()
    a = rows[0]
    b = next(r for r in rows if r["batch_id"] == a["batch_id"] and r["slot_id"] != a["slot_id"])
    res = client.put(f"/api/timetable/{a['id']}", json={"slot_id": b["slot_id"], "room_id": a["room_id"]})
    assert res.status_code == 409 and res.get_json()["conflicts"]


def test_csv_export():
    client = make_client()
    assert client.get("/api/timetable/export").data.startswith(b"batch,day,period")
