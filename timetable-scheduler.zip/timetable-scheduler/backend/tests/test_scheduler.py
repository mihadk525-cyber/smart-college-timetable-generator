from scheduler import (ConflictGraph, Event, Problem, Room, Batch, Slot, TimetableSolver,
                       build_problem, dsatur, find_conflicts)
from scheduler.sample_data import BATCHES, ROOMS, SLOTS, SUBJECTS, UNAVAILABLE


def sample():
    return build_problem(SUBJECTS, BATCHES, ROOMS, SLOTS, UNAVAILABLE)


def test_dsatur_gives_proper_colouring():
    g = ConflictGraph(sample().events)
    colors = dsatur(g)
    assert all(colors[a] != colors[b] for a in g.adj for b in g.adj[a])


def test_clique_needs_three_colours():
    events = [Event(i, i, "X", faculty_id=1, batch_id=i) for i in (1, 2, 3)]  # same faculty
    assert max(dsatur(ConflictGraph(events)).values()) + 1 == 3


def test_sample_timetable_is_solved_without_conflicts():
    problem = sample()
    result = TimetableSolver(problem).solve()
    assert result.success and len(result.assignment) == len(problem.events)
    assert find_conflicts(problem, result.assignment) == []


def test_faculty_unavailability_is_respected():
    problem = sample()
    result = TimetableSolver(problem).solve()
    ev = {e.id: e for e in problem.events}
    for eid, (slot_id, _) in result.assignment.items():
        if ev[eid].faculty_id == 3:
            assert slot_id not in (1, 2)


def test_unsolvable_problem_is_reported():
    events = [Event(1, 1, "A", 1, 1), Event(2, 2, "B", 1, 2)]   # same teacher, only one slot
    problem = Problem(events, [Room(1, "R", 60)], [Batch(1, "X", 30), Batch(2, "Y", 30)], [Slot(1, 0, 0)])
    assert not TimetableSolver(problem).solve().success


def test_validator_detects_batch_clash():
    problem = sample()
    # events 1 and 2 are both lectures of batch 1 -> same slot is a clash
    issues = find_conflicts(problem, {1: (5, 1), 2: (5, 2)})
    assert any("double-booked" in i for i in issues)
