import heapq


def dsatur(graph):
    """Graph colouring with the DSATUR greedy heuristic.

    Always colour the vertex with the most distinct neighbour colours
    ("saturation"); break ties by highest degree. A max-priority queue (heapq with
    negated keys, lazy deletion of stale entries) picks the next vertex.

    Colour = time-slot class. If colours_used <= number of slots, a clash-free slot
    assignment is guaranteed (ignoring rooms / faculty availability).
    Time O((n + m) log n), space O(n + m).  Returns {vertex_id: colour_index}.
    """
    color = {}
    seen = {v: set() for v in graph.adj}                    # colours used by neighbours
    heap = [(0, -len(graph.adj[v]), v) for v in graph.adj]  # (-saturation, -degree, id)
    heapq.heapify(heap)
    while heap:
        neg_sat, _, v = heapq.heappop(heap)
        if v in color or -neg_sat != len(seen[v]):
            continue                                        # stale entry
        c = 0
        while c in seen[v]:
            c += 1
        color[v] = c
        for u in graph.adj[v]:
            if u not in color:
                seen[u].add(c)
                heapq.heappush(heap, (-len(seen[u]), -len(graph.adj[u]), u))
    return color
