"""Plain data classes + a helper that turns database rows into a scheduling problem."""
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Event:
    """One lecture that must be placed in exactly one (slot, room)."""
    id: int
    subject_id: int
    label: str
    faculty_id: int
    batch_id: int
    needs_lab: bool = False


@dataclass(frozen=True)
class Room:
    id: int
    name: str
    capacity: int
    is_lab: bool = False


@dataclass(frozen=True)
class Batch:
    id: int
    name: str
    size: int


@dataclass(frozen=True)
class Slot:
    id: int
    day: int      # 0 = Monday ... 4 = Friday
    period: int   # 0-based period inside the day


@dataclass
class Problem:
    events: list
    rooms: list
    batches: list
    slots: list
    unavailable: dict = field(default_factory=dict)  # faculty_id -> {slot_id, ...}


def build_problem(subjects, batches, rooms, slots, unavailable=None):
    """Inputs are lists of dicts (e.g. database rows). Each subject expands into
    `lectures_per_week` separate events."""
    events = []
    for s in subjects:
        for _ in range(s["lectures_per_week"]):
            events.append(Event(len(events) + 1, s["id"], s["code"],
                                s["faculty_id"], s["batch_id"], bool(s["is_lab"])))
    return Problem(events, [Room(**r) for r in rooms], [Batch(**b) for b in batches],
                   [Slot(**s) for s in slots], unavailable or {})
