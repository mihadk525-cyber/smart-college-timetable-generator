"""Sample data for the demo and tests.
REPLACE these lists with the real Sunstone faculty, rooms, batches and subjects."""
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri"]
PERIODS_PER_DAY = 6

FACULTY = [{"id": i + 1, "name": n} for i, n in enumerate([
    "Dr. A. Sharma", "Prof. R. Verma", "Dr. S. Gupta", "Prof. M. Singh",
    "Dr. P. Jain", "Prof. K. Mehta", "Dr. N. Agarwal", "Prof. T. Khan"])]

BATCHES = [{"id": 1, "name": "CSE-3A", "size": 60},
           {"id": 2, "name": "CSE-3B", "size": 55},
           {"id": 3, "name": "CSE-5A", "size": 50}]

ROOMS = [{"id": 1, "name": "R101", "capacity": 65, "is_lab": False},
         {"id": 2, "name": "R102", "capacity": 60, "is_lab": False},
         {"id": 3, "name": "R201", "capacity": 60, "is_lab": False},
         {"id": 4, "name": "R202", "capacity": 50, "is_lab": False},
         {"id": 5, "name": "Lab-1", "capacity": 60, "is_lab": True},
         {"id": 6, "name": "Lab-2", "capacity": 60, "is_lab": True}]

SLOTS = [{"id": d * PERIODS_PER_DAY + p + 1, "day": d, "period": p}
         for d in range(5) for p in range(PERIODS_PER_DAY)]

# (code, name, faculty_id, batch_id, lectures_per_week, is_lab)
_SUBJECTS = [
    ("DSA", "Data Structures", 1, 1, 4, False), ("DBMS", "Database Management", 2, 1, 3, False),
    ("OS", "Operating Systems", 3, 1, 3, False), ("MATH", "Discrete Mathematics", 4, 1, 3, False),
    ("DSA-L", "DSA Lab", 1, 1, 2, True),
    ("DSA", "Data Structures", 5, 2, 4, False), ("DBMS", "Database Management", 2, 2, 3, False),
    ("OS", "Operating Systems", 3, 2, 3, False), ("MATH", "Discrete Mathematics", 4, 2, 3, False),
    ("DBMS-L", "DBMS Lab", 6, 2, 2, True),
    ("CD", "Compiler Design", 7, 3, 3, False), ("AI", "Artificial Intelligence", 8, 3, 3, False),
    ("CN", "Computer Networks", 6, 3, 3, False), ("WT", "Web Technologies", 5, 3, 3, False),
    ("AI-L", "AI Lab", 8, 3, 2, True),
]
SUBJECTS = [{"id": i + 1, "code": c, "name": n, "faculty_id": f, "batch_id": b,
             "lectures_per_week": l, "is_lab": lab}
            for i, (c, n, f, b, l, lab) in enumerate(_SUBJECTS)]

UNAVAILABLE = {3: {1, 2}}   # Dr. Gupta is unavailable Monday periods 1-2
