def find_conflicts(problem, assignment):
    """Check a (possibly hand-edited) timetable. assignment = {event_id: (slot_id, room_id)}.

    A hash map keyed by (resource kind, resource id, slot) detects double-booking of a
    faculty member, batch or room in O(n). Returns a list of readable messages
    (empty list = valid timetable).
    """
    events = {e.id: e for e in problem.events}
    rooms = {r.id: r for r in problem.rooms}
    batches = {b.id: b for b in problem.batches}
    seen, issues = {}, []
    for ev_id, (slot_id, room_id) in assignment.items():
        e, room = events[ev_id], rooms[room_id]
        for kind, rid in (("faculty", e.faculty_id), ("batch", e.batch_id), ("room", room_id)):
            key = (kind, rid, slot_id)
            if key in seen:
                issues.append(f"{kind} {rid} is double-booked in slot {slot_id} "
                              f"({events[seen[key]].label} and {e.label})")
            else:
                seen[key] = ev_id
        if room.capacity < batches[e.batch_id].size:
            issues.append(f"{room.name} is too small for {e.label}")
        if room.is_lab != e.needs_lab:
            issues.append(f"{e.label} needs a {'lab' if e.needs_lab else 'classroom'}, got {room.name}")
        if slot_id in problem.unavailable.get(e.faculty_id, ()):
            issues.append(f"faculty {e.faculty_id} is unavailable in slot {slot_id} ({e.label})")
    return issues
