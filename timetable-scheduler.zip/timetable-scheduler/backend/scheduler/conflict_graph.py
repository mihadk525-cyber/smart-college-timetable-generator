from collections import defaultdict


class ConflictGraph:
    """Vertex = one lecture. Edge = the two lectures can never share a time slot
    (same faculty or same batch). Stored as an adjacency list: hash map of sets.

    Build: O(sum of g^2) over faculty/batch groups, worst case O(n^2). Space O(n + m).
    """

    def __init__(self, events):
        self.adj = {e.id: set() for e in events}
        groups = defaultdict(list)
        for e in events:
            groups[("faculty", e.faculty_id)].append(e.id)
            groups[("batch", e.batch_id)].append(e.id)
        for ids in groups.values():
            for i, a in enumerate(ids):
                for b in ids[i + 1:]:
                    self.adj[a].add(b)
                    self.adj[b].add(a)

    def edge_count(self):
        return sum(len(n) for n in self.adj.values()) // 2
