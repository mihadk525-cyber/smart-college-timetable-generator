"""Phase-1 demo (no frontend, no database):  python -m scheduler.demo"""
from . import build_problem, TimetableSolver, find_conflicts
from .sample_data import BATCHES, ROOMS, SLOTS, SUBJECTS, UNAVAILABLE, DAYS


def print_timetable(problem, assignment):
    ev = {e.id: e for e in problem.events}
    room_name = {r.id: r.name for r in problem.rooms}
    slot = {s.id: s for s in problem.slots}
    periods = sorted({s.period for s in problem.slots})
    for b in problem.batches:
        grid = {}
        for eid, (sid, rid) in assignment.items():
            if ev[eid].batch_id == b.id:
                grid[(slot[sid].period, slot[sid].day)] = f"{ev[eid].label}@{room_name[rid]}"
        print(f"\n=== {b.name} ===")
        print("     " + "".join(f"{d:<15}" for d in DAYS))
        for p in periods:
            print(f"P{p + 1:<4}" + "".join(f"{grid.get((p, d), '-'):<15}" for d in range(len(DAYS))))


def main():
    problem = build_problem(SUBJECTS, BATCHES, ROOMS, SLOTS, UNAVAILABLE)
    result = TimetableSolver(problem).solve()
    print(f"lectures: {len(problem.events)} | conflict-graph edges: {result.graph_edges} | "
          f"DSATUR colours (slots needed, upper bound): {result.colors_used} of {len(problem.slots)}")
    print(f"solved: {result.success} | backtracking nodes: {result.nodes} | {result.elapsed_ms:.1f} ms")
    if result.success:
        print_timetable(problem, result.assignment)
        print("\nconflicts found by validator:", find_conflicts(problem, result.assignment) or "none")
    else:
        print(result.message)


if __name__ == "__main__":
    main()
