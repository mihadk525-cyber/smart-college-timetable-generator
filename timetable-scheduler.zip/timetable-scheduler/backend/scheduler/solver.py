"""Timetable generation as a Constraint Satisfaction Problem (CSP).

Variables : one per lecture (Event)
Domain    : every (slot, room) pair the lecture could legally use
Constraints: lectures sharing a faculty or batch never share a slot (ConflictGraph edges),
             no two lectures share (slot, room), room capacity / lab type,
             faculty unavailability (removed from the domains up front).

Search    : recursive backtracking with
            * MRV (Minimum Remaining Values)  - pick the lecture with the smallest domain
            * forward checking                - prune neighbours' domains after each choice
            * greedy value ordering           - prefer days where the batch has fewer lectures
Worst case is exponential O((S*R)^n); pruning makes realistic timetables solve quickly.
"""
import sys
import time
from dataclasses import dataclass

from .coloring import dsatur
from .conflict_graph import ConflictGraph


class _SearchLimit(Exception):
    pass


@dataclass
class SolveResult:
    success: bool
    assignment: dict      # {event_id: (slot_id, room_id)}
    nodes: int            # backtracking nodes explored
    elapsed_ms: float
    colors_used: int      # DSATUR upper bound on slots needed
    graph_edges: int
    message: str = ""


class TimetableSolver:
    def __init__(self, problem, node_limit=200_000):
        self.p = problem
        self.node_limit = node_limit
        self.graph = ConflictGraph(problem.events)
        self.event = {e.id: e for e in problem.events}
        self.slot_day = {s.id: s.day for s in problem.slots}
        self.day_load = {}      # (batch_id, day) -> lectures already placed
        self.nodes = 0
        sys.setrecursionlimit(max(10_000, sys.getrecursionlimit()))

    def _initial_domains(self):
        size = {b.id: b.size for b in self.p.batches}
        domains = {}
        for e in self.p.events:
            blocked = self.p.unavailable.get(e.faculty_id, set())
            domains[e.id] = {(s.id, r.id)
                             for s in self.p.slots if s.id not in blocked
                             for r in self.p.rooms
                             if r.is_lab == e.needs_lab and r.capacity >= size[e.batch_id]}
        return domains

    def solve(self):
        start = time.perf_counter()
        colors = dsatur(self.graph)
        used = max(colors.values(), default=-1) + 1
        domains = self._initial_domains()
        assignment, message = {}, ""
        if any(not d for d in domains.values()):
            ok, message = False, "A lecture has no valid slot/room: check room capacity, lab rooms and faculty availability."
        else:
            try:
                ok = self._backtrack(domains, assignment)
                if not ok:
                    message = "No valid timetable exists for these constraints. Add slots/rooms or reduce lectures."
            except _SearchLimit:
                ok, message = False, f"Stopped after {self.node_limit} search nodes without a solution."
        return SolveResult(ok, dict(assignment) if ok else {}, self.nodes,
                           (time.perf_counter() - start) * 1000, used,
                           self.graph.edge_count(), message)

    def _backtrack(self, domains, assignment):
        if len(assignment) == len(domains):
            return True
        self.nodes += 1
        if self.nodes > self.node_limit:
            raise _SearchLimit()
        ev = min((i for i in domains if i not in assignment),
                 key=lambda i: (len(domains[i]), -len(self.graph.adj[i])))   # MRV, then degree
        for slot, room in self._ordered_values(ev, domains[ev]):
            removed = []
            if self._assign(ev, slot, room, domains, assignment, removed) \
                    and self._backtrack(domains, assignment):
                return True
            self._undo(ev, slot, domains, assignment, removed)               # backtrack
        return False

    def _ordered_values(self, ev, domain):
        batch = self.event[ev].batch_id
        return sorted(domain, key=lambda v: (self.day_load.get((batch, self.slot_day[v[0]]), 0), v))

    def _assign(self, ev, slot, room, domains, assignment, removed):
        assignment[ev] = (slot, room)
        key = (self.event[ev].batch_id, self.slot_day[slot])
        self.day_load[key] = self.day_load.get(key, 0) + 1
        neighbours = self.graph.adj[ev]
        for other, dom in domains.items():            # forward checking
            if other in assignment:
                continue
            gone = {v for v in dom if v[0] == slot and (other in neighbours or v[1] == room)}
            if gone:
                dom -= gone
                removed.append((other, gone))
                if not dom:
                    return False                      # domain wipe-out -> dead end
        return True

    def _undo(self, ev, slot, domains, assignment, removed):
        for other, gone in removed:
            domains[other] |= gone
        del assignment[ev]
        self.day_load[(self.event[ev].batch_id, self.slot_day[slot])] -= 1
